# Define your database connections
postgres_conn = {
    'host': 'localhost',
    'port': '5432',
    'database': 'postgres',
    'user': 'postgres',
    'password': 'password'
}

mysql_connv = {
    'host': '127.0.0.1',
    'port': '3306',
    'database': 'housing_data',
    'user': 'root',
    'password': 'Magfum12@'
}
mysql_conn = {
    'host': '127.0.0.1',
    'port': '3306',
    'database': 'housing_data',
    'user': 'root',
    'password': 'Magfum12@'
}